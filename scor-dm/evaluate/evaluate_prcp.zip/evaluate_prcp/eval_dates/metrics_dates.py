# sbgm/evaluate/evaluate_prcp/eval_dates/metrics_dates.py
"""
No scalar metrics for 'eval_dates' at the moment — this module exists for symmetry
and future extension (e.g., per-date scalar summaries).
"""
from __future__ import annotations
